package com.mycom.myboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
