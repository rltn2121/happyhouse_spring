package com.ssafy.vue.dto;

import lombok.Data;

@Data
public class HouseDealInfoDto {
   
//   private int no;
//   private int aptCode;
//   private String aptName;
//   private String dongCode;
//   private String dealAmount;
//   private int dealYear;
//   private int dealMonth;
//   private int dealDay;
//   private double area;
//   private int floor;
//   private int type;
//   private String sidoName;
//   private String gugunName;
//   private String dongName;
//   private String jibun;
//   
//   private int buildYear;
//   private String lat;
//   private String lng;
	private int aptCode;
	private double area;
   private String dealAmount;
   private int dealYear;
   private int dealMonth;
   private int dealDay;
}