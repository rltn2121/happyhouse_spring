package com.ssafy.vue.dto;

import lombok.Data;

@Data
public class Budongsan {
	private int bdsId;
	private int aptCode;
	private int price;
	private double area;
	private int floor;
	private int type;
	private int ownerId;
}